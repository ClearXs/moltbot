---
name: project-os-organizer
description: Organize project workspace files and generate a concise summary.
---

# Project OS Organizer

Use this skill to organize common project folders and output a quick status report.

## Steps

1. Scan the workspace for docs, source, tests, and scripts.
2. Propose a clean folder grouping.
3. Generate a short markdown summary.
