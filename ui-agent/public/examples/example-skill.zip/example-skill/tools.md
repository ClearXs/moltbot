# tools

- rg
- git
